﻿   <?
       include("../modelo/Area.php");
       include("../control/CtrArea.php");
       include("../control/CtrConexion.php");
       $cod=".";
      $nombre=".";
      $subarea=".";
      $botonGuardar="";
      $botonConsultar = "";
      $botonModificar = "";
      $botonBorrar = "";
      $nombre=$_POST["Nombre"];
	    $subarea=$_POST["subarea"];
      $cod= $_POST ["Cod"]; 
     
	 $botonGuardar=$_POST["Guardar"];
	 $botonConsultar=$_POST["Consultar"];
	 $botonModificar=$_POST["Modificar"];
	 $botonBorrar=$_POST["Borrar"];    

     if($botonGuardar=="Guardar"){

           try{  
             $objArea=new Area($cod,$nombre,$subarea);
             $objCtrArea =new CtrArea($objArea);

             $objCtrArea->guardar();
             $mat = $objCtrArea->listar();
             $longitud = count($mat);
             }
             catch(Exception $exp){
                    echo "ERROR ....R ".$exp->getMessage()."\n";
             }

    }
    if($botonConsultar=="Consultar"){

        try{
            $objArea=new Area($cod,$nombre,$subarea);
            $objCtrArea =new CtrArea($objArea);


          if($objCtrArea->consultar()){ 
              echo "<center> <h1>SE HA REALIZADO LA CONSULTA</h1></center>";
              echo $objArea->getCod_Area(). "\n";
              echo $objArea->getNombre(). "\n";
              echo $objArea->getsubarea(). "\n";             


          }
          else{
             echo "<center> <h1>NO SE HA PODIDO REALIZAR LA CONSULTA</h1></center>";
             }
          }
          catch(Exception $exp){
                 echo "ERROR ....R ".$exp->getMessage()."\n";
          }

    }

 if($botonModificar=="Modificar"){

    try{
        $objArea=new Area($cod,$nombre,$subarea);
        $objCtrArea =new CtrArea($objArea);


      if(!$objCtrArea->modificar()){
          echo "<center> <h1>SE HA MODIFICADO CON EXITO</h1></center>";
      }
      else{
         echo "<center> <h1>NO SE HA ENCONTRADO EL NOMBRE INGRESADO</h1></center>";
         }
      }
      catch(Exception $exp){
             echo "ERROR ....R ".$exp->getMessage()."\n";
      }

}
if($botonBorrar=="Borrar"){

    try{
        $objArea=new Area($cod,$nombre,$subarea);
        $objCtrArea =new CtrArea($objArea);


      if(!$objCtrArea->borrar()){ 
          echo "<center> <h1>SE HA BORRADO CON EXITO DE LA BASE DE DATOS</h1></center>";
      }
      else{
         echo "<center> <h1>NO SE HA ENCONTRADO NADA CON ESTE NOMBRE</h1></center>";
         }
      }
      catch(Exception $exp){
             echo "ERROR ....R ".$exp->getMessage()."\n";
      }

}

echo "<!doctype html>
<html lang=\"en\">

<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
  <meta name=\"description\" content=\"\">
  <meta name=\"author\" content=\"\">
  <link rel=\"icon\" href=\"../../../../favicon.ico\">

  <title>User</title>

  <!-- Bootstrap core CSS -->
  <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css\" integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\"
    crossorigin=\"anonymous\">
  <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.2.0/css/all.css\" integrity=\"sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ\"
    crossorigin=\"anonymous\">
  <!-- Custom styles for this template -->
  <link href=\"styles.css\" rel=\"stylesheet\">
</head>

<body>
  

  <div class=\"container-fluid\">
    <div class=\"row\">
      <main role=\"main\" class=\"col-md-9 ml-sm-auto col-lg-10 px-4\">
        <!--Form Clients-->
        <a href=\"#\" class=\"badge badge-primary\">
          <span>
            <i class=\"fas fa-chevron-circle-left\"></i>
          </span> Go home</a>
        <br>
        <br>
        <div class=\"card\">
          <h1 class=\"card-header\" style=\"text-align: center;\">User</h1>
          <div class=\"card-body\">
            <form method=\"POST\" action=\"Area.php\">
              <div class=\"form\">
                <div class=\"form-group\">
                    <label for=\"lname\">Código Área</label>
                    <input type=\"text\" class=\"form-control\" name=\"Cod\" placeholder=\"cod\" autocomplete=\"off\" >
                </div>
                <div class=\"form-group\">
                  <label for=\"lname\">Nombre</label>
                  <input type=\"text\" class=\"form-control\" name=\"Nombre\" placeholder=\"Nombre\" autocomplete=\"off\">
                </div>
                <div class=\"form-group\">
                    <label for=\"tele\">Subárea</label>
                    <input type=\"text\" class=\"form-control\" name=\"subarea\" placeholder=\"subarea\" autocomplete=\"off\">
                </div>
              </div>
              <div class=\"form-group\">
                <div class=\"row\">
                  <div class=\"col-md-6\">
                    <button type=\"submit\" name=\"Guardar\" value=\"Guardar\" class=\"btn btn-success btn-lg btn-block\">
                      <span>
                        <i class=\"fas fa-user-plus\"></i>
                      </span> Guardar</button>
                  </div>
                  <div class=\"col-md-6\">
                    <button type=\"submit\" name=\"Consultar\" value=\"Consultar\" class=\"btn btn-primary btn-lg btn-block\">
                      <span>
                        <i class=\"fas fa-search\"></i>
                      </span> Consultar</button>
                  </div>
                </div>
                <br>
                <div class=\"row\">
                  <div class=\"col-md-6\">
                    <button type=\"submit\" name=\"Modificar\" value=\"Modificar\" class=\"btn btn-dark btn-lg btn-block\">
                      <span>
                        <i class=\"fas fa-wrench\"></i>
                      </span> Modificar</button>
                  </div>
                  <div class=\"col-md-6\">
                    <button type=\"submit\" name=\"Borrar\" value=\"Borrar\" class=\"btn btn-danger btn-lg btn-block\">
                      <span>
                        <i class=\"fas fa-trash\"></i>
                      </span> Borrar</button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
        <!--end Form Clients-->";
        // $mat = $objCtrArea->listar();
        for ($i=1; $i<= $longitud ; $i++) { 
          echo  " <div class=\"table-responsive\">
          <table class=\"table table-striped table-sm\">
              <thead>
                  <tr>
                      <th>Código Área</th>
                      <th>Nombre</th>
                      <th>Subárea</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>".$mat[$i][1]."</td>
                      <td> ".$mat[$i][2]."</td>
                      <td>".$mat[$i][3]."</td>
                  </tr>
              </tbody>  
          </table>
      </div>";
      }
        echo "
      </main>
    </div>
  </div>
  <!-- Bootstrap core JS -->
  <script src=\"https://code.jquery.com/jquery-3.3.1.slim.min.js\" integrity=\"sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo\"
    crossorigin=\"anonymous\"></script>
  <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js\" integrity=\"sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49\"
    crossorigin=\"anonymous\"></script>
  <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js\" integrity=\"sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy\"
    crossorigin=\"anonymous\"></script>
</body>

</html>";
?>

