<?
 class Area{
        var $cod_area="";
        var $nombre="";
        var $subarea="";

        function Area($cod_area,$nombre,$subarea){
        $this->cod_area = $cod_area;
        $this->nombre = $nombre;
        $this->subarea = $subarea;
        }

/*    function Usuario() {
        $this.nomUsuario = "";
        $this.contrasena = "";
    }
*/
function getCod_Area() {
    return $this->cod_area;
}

function setCod_Area($cod_area) {
    $this->cod_area = $cod_area;
}

    function getNombre() {
        return $this->nombre;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }
    function getsubarea() {
        return $this->subarea;
    }

    function setsubarea($subarea) {
        $this->subarea = $subarea;
    }
}
    
?>