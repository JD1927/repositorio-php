<?
    class CtrArea{
	var $objArea;
	var $recordSet;
        function CtrArea($objArea){
         $this->objArea=$objArea;

        }

        function guardar(){

        $cod=$this->objArea->getCod_Area();
        $nombre=$this->objArea->getNombre();
        $subarea=$this->objArea->getsubarea();



		//---------NOS CONECTAMOS A LA BASE DE DATOS-----------------------------------------------------------
        $bd="Repositorio";
        $ObjConexion=new CtrConexion();
        $enlace=$ObjConexion->conectar('localhost',$bd,'root','');


		//--------------Se ejecuta Comando SQL-------------------------


        $consulta="INSERT into area (IDAREA,NOMBRE,FKIDAREA) values ('".$cod."','".$nombre."',NULL)";
         echo " Comando SQL : ". $consulta;
		$recordSet=$ObjConexion->ejecutarSql($bd,$consulta);
         $ObjConexion->cerrar($enlace);
		//--------------VERIFICAMOS SI SE REALIZO LA CONSULTA--------------------------------------------------
		if (!$recordSet)
		{
			die(" ERROR CON EL COMANDO SQL: ".mysql_error());
		}
		else
		{
			//----------AL RESULTADO QUE SE VA A RETORNAR = RESULTADO DE LA CONSULTA---------------
	    $this->recordSet=$recordSet;

		}

        }
        function listar(){
    
            //---------NOS CONECTAMOS A LA BASE DE DATOS-----------------------------------------------------------
            $bd="Repositorio";
            $ObjConexion=new CtrConexion();
            $enlace=$ObjConexion->conectar('localhost',$bd,'root','');
    
    
            //--------------Se ejecuta Comando SQL-------------------------
    
    
            $consulta="SELECT * FROM AREA";
            //  echo " Comando SQL : ". $consulta;
            $recordSet=$ObjConexion->ejecutarSql($bd,$consulta);
            $i =0;
            $registro = mysql_fetch_array($recordSet);
            $mat [0][0] = 3;
            while ($registro){
            $mat [$i][1] = $registro['IDAREA'];
            $mat [$i][2] = $registro['NOMBRE'];
            $mat [$i][3] = $registro['FKIDAREA'];
            
            $registro = mysql_fetch_array($recordSet);   
            $i = $i + 1;
            }

            
            $ObjConexion->cerrar($enlace);

            
            //--------------VERIFICAMOS SI SE REALIZO LA CONSULTA--------------------------------------------------
            if (!$recordSet)
            {
                die(" ERROR CON EL COMANDO SQL: ".mysql_error());
            }
            else
            {
                //----------AL RESULTADO QUE SE VA A RETORNAR = RESULTADO DE LA CONSULTA---------------
            return $mat;
    
            }
    
        }
        function modificar(){
        $cod=$this->objArea->getCod_Area();
        $nombre=$this->objArea->getNombre();
        $subarea=$this->objArea->getsubarea();
        


		//---------NOS CONECTAMOS A LA BASE DE DATOS-----------------------------------------------------------
        $bd="Repositorio";
        $ObjConexion=new CtrConexion();
        $enlace=$ObjConexion->conectar('localhost',$bd,'root','');


		//--------------Se ejecuta Comando SQL-------------------------


        $consulta="UPDATE AREA set NOMBRE='".$nombre."', FKIDAREA='".$subarea."' where IDAREA ='".$cod."'";
         echo " Comando SQL : ". $consulta;
		$recordSet=$ObjConexion->ejecutarSql($bd,$consulta);
         $ObjConexion->cerrar($enlace);
		//--------------VERIFICAMOS SI SE REALIZO LA CONSULTA--------------------------------------------------
		if (!$recordSet)
		{
			die(" ERROR CON EL COMANDO SQL: ".mysql_error());
		}
		else
		{
			//----------AL RESULTADO QUE SE VA A RETORNAR = RESULTADO DE LA CONSULTA---------------
	        $this->recordSet=$recordSet;

		}

        }
        function borrar(){
        $cod=$this->objArea->getCod_Area();

		//---------NOS CONECTAMOS A LA BASE DE DATOS-----------------------------------------------------------
        $bd="Repositorio";
        $ObjConexion=new CtrConexion();
        $enlace=$ObjConexion->conectar('localhost',$bd,'root','');


		//--------------Se ejecuta Comando SQL-------------------------


        $consulta="DELETE from AREA where IDAREA ='".$cod."'";
         echo " Comando SQL : ". $consulta;
		$recordSet=$ObjConexion->ejecutarSql($bd,$consulta);
         $ObjConexion->cerrar($enlace);
		//--------------VERIFICAMOS SI SE REALIZO LA CONSULTA--------------------------------------------------
		if (!$recordSet)
		{
			die(" ERROR CON EL COMANDO SQL: ".mysql_error());
		}
		else
		{
			//----------AL RESULTADO QUE SE VA A RETORNAR = RESULTADO DE LA CONSULTA---------------
	$this->recordSet=$recordSet;

		}

        }
        function consultar(){
        $cod=$this->objArea->getCod_Area();

        $bd="Repositorio";
        $ObjConexion=new CtrConexion();
        $enlace=$ObjConexion->conectar('localhost',$bd,'root','');

        $consulta="SELECT * from AREA where IDAREA ='".$cod."'";
        // echo " Comando SQL : ". $consulta."<br>";
		$recordSet=$ObjConexion->ejecutarSql($bd,$consulta);

        // LA FUNCI�N  mysql_fetch_array   PERMITE RECORRER EL RECORDSET (CURSOR A LA TABLA)
        // AQU� SE ASIGNA EL CONTENIDO DEL PRIMER REGISTRO DEL RECORDSET A UNA VARIABLE IDENTIFICADA COMO:

        $registro = mysql_fetch_array($recordSet);

        $this->objArea->setCod_Area($registro['IDAREA']);
        $this->objArea->setNombre($registro['NOMBRE']);
        $this->objArea->setsubarea($registro['IDFKAREA']);

        $ObjConexion->cerrar($enlace);
		//--------------VERIFICAMOS SI SE REALIZO LA CONSULTA--------------------------------------------------
		if (!$recordSet)
		{
			die(" ERROR CON EL COMANDO SQL: ".mysql_error())."<br>";
		}
		else
		{
			//----------AL RESULTADO QUE SE VA A RETORNAR = RESULTADO DE LA CONSULTA---------------
	    return $this->objArea;

		}

        }



        // function listar(){

        // $bd="facturas";
        // $ObjConexion=new CtrConexion();
        // $enlace=$ObjConexion->conectar('localhost',$bd,'root','');
        // $consulta="select * from Usuarios";
        //       $recordSet=$ObjConexion->ejecutarSql($bd,$consulta);

        // // LA FUNCI�N  mysql_num_rows DEVUELVE EL N�MERO DE REGISTROS DEL RECORDSET
        //       $numRegistros = mysql_num_rows($recordSet);

        // //SE ASIGNA EN UNA POSICI�N DESOCUPADA (EN ESTE CASO LA $mat[0][0], EL VALOR CON EL N�MERO DE REGISTROS
        //       $mat[0][0]= $numRegistros;
        //       $i=0;

        // // LA FUNCI�N  mysql_fetch_array   PERMITE RECORRER EL RECORDSET (CURSOR A LA TABLA Usuario)
        // // AQU� SE ASIGNA EL CONTENIDO DEL PRIMER REGISTRO DEL RECORDSET A UNA VARIABLE IDENTIFICADA COMO:
        // //  $registro
        // //CON EL CICLO MIENTRAS SE ASIGNA CADA REGISTRO DEL RECORDSET A CADA FILA DE LA MATRIZ
        //       while ($registro = mysql_fetch_array($recordSet)){
	    //       $i=$i+1;
        //       $mat[$i][0]=  $registro['usuario'];
        //       $mat[$i][1]=  $registro['contrasena'];

        //        }

        // //SE LIBERA MEMORIA DEL CURSOR ($recordSet) CON LA FUNCI�N  mysql_free_result
        //       mysql_free_result($recordSet);
        //       $ObjConexion->cerrar($enlace);

        // //RETORNA LA MATRIZ CON LOS REGISTROS, PARA SER RECORRIDA EN LA VISTA (VistaUsuario.php)
        //       return $mat;
        // }

//        function  validarIngreso(){
//             $esValido=false;
//             $objUsuario1 = new Usuario('','');
// 	        $ObjConexion=new CtrConexion();
//             $bd="facturas";
//             $enlace=$ObjConexion->conectar('localhost',$bd,'root','');

//             $consulta= "select * from Usuarios where usuarios.Usuario='" . $this->objUsuario->getNomUsuario().
//              "' and usuarios.contrasena= '" . $this->objUsuario->getContrasena(). "'";

//              try{
//                  $recordSet=$ObjConexion->ejecutarSql($bd,$consulta);
//                  $registro = mysql_fetch_array($recordSet);
//                  $objUsuario1->setNomUsuario($registro['usuario']);
//                  $objUsuario1->setContrasena($registro['contrasena']);
// ;
//                 }
//          	catch (Exception $e)
//             	{
//             	echo "ERROR SELECCIONANDO EN LA BASE DE DATOS".$e->getMessage()."\n";
//                 }
//                  $ObjConexion->cerrar($enlace);

//             if ($this->objUsuario->getNomUsuario()==$objUsuario1->getNomUsuario() &&
//                $this->objUsuario->getContrasena()==$objUsuario1->getContrasena()  &&
//                $this->objUsuario->getNomUsuario() != "" &&
//                $this->objUsuario->getContrasena() != ""){
//                  $esValido = true;
//             }
//             else
//                 {
//                 $esValido = false;
//                 }
//              return $esValido;

//       }
 }


?>